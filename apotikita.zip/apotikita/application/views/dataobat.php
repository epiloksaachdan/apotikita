<div class="container-fluid">
    <div class="row">
        <div class="col-12 py-5 px-5">
            <table class="table table-striped table-hover table-bordered">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kode obat</th>
                        <th>Nama obat</th>
                        <th>Harga</th>
                        <th>Produsen</th>
                        <th>Suplier</th>
                        <th>Stok</th>
                        <th>Opsi</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th scope="row">1</th>
                        <td>.</td>
                        <td>.</td>
                        <td>.</td>
                        <td>.</td>
                        <td>.</td>
                        <td>.</td>
                        <td>.</td>
                    </tr>
                    <tr>
                        <th scope="row">2</th>
                        <td>.</td>
                        <td>.</td>
                        <td>.</td>
                        <td>.</td>
                        <td>.</td>
                        <td>.</td>
                        <td>.</td>
                    </tr>

                </tbody>
            </table>
        </div>
    </div>
</div>